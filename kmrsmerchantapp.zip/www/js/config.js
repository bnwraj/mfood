
var krms_config ={			
	'ApiUrl' : "http://mfood.testinghive.com/merchantapp/api",	
	'DialogDefaultTitle' : "mFood Merchant",
	'pushNotificationSenderid' : "688623216057",
	'APIHasKey' : "Bnwraj-1122"
};